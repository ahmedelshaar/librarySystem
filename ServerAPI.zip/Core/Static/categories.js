exports.categories = [
  "Adventure stories",
  "Classics",
  "Crime",
  "Fairy tales",
  "Fantasy",
  "Historical fiction",
  "Horror",
  "Humour and satire",
  "Literary fiction",
  "Mystery",
  "Poetry",
  "Plays",
  "Romance",
  "Science fiction",
  "Short stories",
  "Thrillers",
  "War",
  "Women’s fiction",
  "Young adult",
];
